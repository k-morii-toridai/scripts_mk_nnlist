#!/bin/bash

# cif2cellがインストールされているか確認
if ! command -v cif2cell &> /dev/null
then
    echo "cif2cellが見つかりません。インストールを開始します。"
    
    # インストール
    pip install git+https://github.com/torbjornbjorkman/cif2cell.git
else
    echo "cif2cellは既にインストールされています。"
fi

# convert cif to POSCAR by cif2cell
cif2cell ABW.cif -p vasp -o POSCAR --vasp-format=5

# make POSCAR.nnlist from POSCAR by poscar2nnlist
./poscar2nnlist POSCAR 10
